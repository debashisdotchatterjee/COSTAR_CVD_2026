# COSTAR-CVD: reproducible statistical research output

Generated UTC: 2026-10-28T03:05:41.793490+00:00

**Interpretation:** OFFLINE, retrospective decision simulation; NOT clinical advice.

## Frozen study design

- Random seed: 20261028; split: 600 development / 200 policy optimization / 200 evaluation, no stratification.
- Stage B: age, gender, chestpain, restingBP, serumcholestrol, fastingbloodsugar, restingrelectro.
- Stage A: maxheartrate, exerciseangia, oldpeak, slope. noofmajorvessels excluded from all primary decisions.
- Serum cholesterol zeros recoded as missing; imputation and indicator fitted in training folds only.
- Cross-fitted stacking and sigmoid recalibration use only development labels; thresholds only optimization labels.
- All statistics reported as independent evaluation once for a prespecified primary policy.

## Primary decision setting

- Costs (test, referral, missed positive): 0.055, 0.18, 1.0.
- Gamma = 1.25; testing capacity = 0.4; referral capacity = 0.58; joint miss limit = 0.42.
- Candidate policies: 1014; feasible on optimization set: 105.
- Selected thresholds (ell, h, t): [0.778337, 0.952075, 0.994979].

## Independent evaluation

- COSTAR: mean loss 0.1884, test use 0.085, referral use 0.465, joint missed fraction 0.100.
- B-only logistic: mean loss 0.1900, test use 0.000, referral use 0.500, joint missed fraction 0.100.
- COSTAR loss is 0.0016 units lower than this logistic comparator; statistical uncertainty is in paired_bootstrap_comparisons.csv.
- All three simultaneous population-capacity safety bounds satisfy the selected tolerances: **True**.
- A point estimate below a tolerance is NOT a certificate; see one-sided upper confidence limits.

## Robust optimization / validation notes

- Maximum numerical error in sorting-oracle versus LP unit tests: 6.66e-16.
- Gamma reweights only observed optimization-set records and is NOT a confidence set for an unknown population.
- LP equivalence is a computational identity; it does not establish clinical or statistical superiority.
- The fixed holdout is not reused for choosing costs, Gamma, budget scenarios, feature access, or thresholds.
- Policy-comparison bootstrap intervals are exploratory and do not replace the independent exact certificate.
- Base-learner score metrics and policy metrics address different estimands.

## Scope and limitations

- The CSV provides recorded disease labels, not prospective cardiovascular outcomes or referral benefits.
- The additional panel is retrospectively observed in the CSV, but its timing/availability is not established.
- Strong slope outcome separation and outcome-linked cholesterol zero coding warrant caution.
- Evaluation assumes IID draws from the same data-generating distribution; it does not test domain shift.
- No actual measurement costs, clinician capacity, randomized testing, or treatment effects are observed.
- Fairness comparisons use only recorded gender codes; underlying semantic validity is not known.

## Output navigation

- `tables/`: machine-readable CSV and manuscript-oriented TeX tables; includes optimization frontier.
- `figures/`: 270-dpi PNG and vector PDF figures.
- `predictions/`: held-out risk scores and decisions; no model tuning is performed on these labels.
- `configuration.json`, `data_audit.json`, `README_RESULTS.md`, `package_versions.json`.

Elapsed computational time: 7.83 minutes.
