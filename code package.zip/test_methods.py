"""Standalone mathematical and software invariants; run before using any results."""
import unittest
import numpy as np
from scipy.optimize import linprog
from COSTAR_CVD_colab import (support, support_binary_counts, worst_case_weights,
            vector_support_loss, candidate_grid, policy_vectors, policy_single,
            cp_upper, Config)

class TestCostarMath(unittest.TestCase):
    def test_exact_robust_oracle_and_attaining_weights(self):
        r=np.random.default_rng(2026)
        for n in (3,19,200):
            for gam in (1.,1.25,1.5,2.):
                z=r.normal(size=n)
                w=worst_case_weights(z,gam)
                self.assertAlmostEqual(np.sum(w),1,places=11)
                self.assertAlmostEqual(support(z,gam),np.dot(z,w),places=10)
                if n<200:
                    lp=linprog(-z,A_eq=np.ones((1,n)),b_eq=[1],
                               bounds=[(1/(n*gam),gam/n)]*n,method='highs')
                    self.assertTrue(lp.success)
                    self.assertAlmostEqual(-lp.fun,support(z,gam),places=9)
    def test_binary_fast_oracle(self):
        n=20
        for gam in (1.,1.25,2.):
            for q in range(n+1):
                z=np.r_[np.ones(q),np.zeros(n-q)]
                self.assertAlmostEqual(float(support_binary_counts(q,n,gam)),
                                       support(z,gam),places=10)
    def test_matrix_sort_oracle(self):
        r=np.random.default_rng(4)
        a=r.normal(size=(20,73))
        for gamma in (1.,1.25,1.5,2.):
            np.testing.assert_allclose(vector_support_loss(a,gamma),
                   np.array([support(row,gamma) for row in a]),atol=1e-12)
    def test_grid_equals_individual_rule(self):
        r=np.random.default_rng(5);B=r.uniform(size=200);S=r.uniform(size=200)
        grid=candidate_grid(B,S,Config(n_grid_quantiles=6))
        M,N=policy_vectors(B,S,grid)
        for k in r.choice(len(grid),size=min(len(grid),100),replace=False):
            t,r0=policy_single(B,S,grid[k])
            np.testing.assert_array_equal(t,M[k]);np.testing.assert_array_equal(r0,N[k])
            self.assertTrue(np.all(r0[t==0]==(B[t==0]>=grid[k,1])))
    def test_cp_boundaries(self):
        self.assertEqual(cp_upper(3,3,.01),1.)
        self.assertEqual(cp_upper(0,0,.01),1.)
        self.assertAlmostEqual(cp_upper(0,200,.01),1-.01**(1/200),places=11)

if __name__=='__main__':unittest.main(verbosity=2)
